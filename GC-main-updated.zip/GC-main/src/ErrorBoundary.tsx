/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
}

// Catches runtime errors anywhere in the component tree below it and shows a
// friendly bilingual fallback screen instead of a blank white page, with a
// button to reload. Without this, any unexpected error crashes the whole app.
export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown, info: unknown) {
    // eslint-disable-next-line no-console
    console.error('GC Simulator crashed:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '1rem',
          padding: '2rem',
          textAlign: 'center',
          backgroundColor: '#0a0f1d',
          color: '#e2e8f0',
          fontFamily: 'sans-serif'
        }}>
          <h1 style={{ fontSize: '1.25rem', fontWeight: 800 }}>
            حدث خطأ غير متوقع / Something went wrong
          </h1>
          <p style={{ maxWidth: '32rem', fontSize: '0.875rem', opacity: 0.8 }}>
            نعتذر عن الإزعاج. الرجاء إعادة تحميل الصفحة. إذا استمرت المشكلة تواصل مع مسؤول المختبر.
            <br />
            Sorry for the inconvenience. Please reload the page. If the problem persists, contact your lab administrator.
          </p>
          <button
            onClick={() => window.location.reload()}
            style={{
              padding: '0.6rem 1.5rem',
              borderRadius: '0.5rem',
              backgroundColor: '#059669',
              color: 'white',
              fontWeight: 700,
              fontSize: '0.875rem',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            إعادة تحميل / Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
